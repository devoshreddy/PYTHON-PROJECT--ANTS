"""
Langton's Ant — interactive Python simulation
Controls:
  SPACE       Pause / resume
  RIGHT       Advance one step while paused
  R           Reset simulation
  UP / DOWN   Increase / decrease simulation speed
  ESC / Q     Quit

Install:
  python -m pip install -r requirements.txt
Run:
  python langtons_ant.py
"""
from __future__ import annotations

import argparse
import sys
import pygame

# Langton's Ant rules:
# On a white cell: turn right, flip the cell to black, move forward.
# On a black cell: turn left, flip the cell to white, move forward.

WHITE = (245, 245, 240)
BLACK = (25, 30, 40)
ANT_COLOR = (220, 70, 65)
GRID_COLOR = (215, 218, 220)
BACKGROUND = (232, 235, 238)
DIRECTIONS = ((0, -1), (1, 0), (0, 1), (-1, 0))  # N, E, S, W


class LangtonsAnt:
    """Stores the ant position, direction, and black-cell set."""

    def __init__(self, width: int, height: int) -> None:
        self.width = width
        self.height = height
        self.reset()

    def reset(self) -> None:
        self.x = self.width // 2
        self.y = self.height // 2
        self.direction = 0  # Start facing north.
        self.black_cells: set[tuple[int, int]] = set()
        self.steps = 0

    def step(self) -> None:
        position = (self.x, self.y)

        if position in self.black_cells:
            self.direction = (self.direction - 1) % 4  # Turn left.
            self.black_cells.remove(position)          # Black -> white.
        else:
            self.direction = (self.direction + 1) % 4  # Turn right.
            self.black_cells.add(position)              # White -> black.

        dx, dy = DIRECTIONS[self.direction]
        self.x = (self.x + dx) % self.width
        self.y = (self.y + dy) % self.height
        self.steps += 1


def draw_simulation(screen: pygame.Surface, ant: LangtonsAnt,
                    cell_size: int, panel_height: int, font: pygame.font.Font,
                    show_grid: bool = True) -> None:
    screen.fill(BACKGROUND)
    board_width = ant.width * cell_size
    board_height = ant.height * cell_size
    board = pygame.Rect(0, panel_height, board_width, board_height)
    pygame.draw.rect(screen, WHITE, board)

    for x, y in ant.black_cells:
        pygame.draw.rect(
            screen, BLACK,
            (x * cell_size, panel_height + y * cell_size, cell_size, cell_size)
        )

    if show_grid and cell_size >= 8:
        for x in range(ant.width + 1):
            px = x * cell_size
            pygame.draw.line(screen, GRID_COLOR,
                             (px, panel_height), (px, panel_height + board_height))
        for y in range(ant.height + 1):
            py = panel_height + y * cell_size
            pygame.draw.line(screen, GRID_COLOR, (0, py), (board_width, py))

    ant_rect = pygame.Rect(
        ant.x * cell_size, panel_height + ant.y * cell_size,
        cell_size, cell_size
    )
    pygame.draw.rect(screen, ANT_COLOR, ant_rect)
    pygame.draw.rect(screen, (255, 255, 255), ant_rect, max(1, cell_size // 10))

    status = (
        f"LANGTON'S ANT   |   Steps: {ant.steps:,}   |   "
        f"Black cells: {len(ant.black_cells):,}"
    )
    controls = "SPACE: pause/resume   RIGHT: step   R: reset   UP/DOWN: speed   ESC: quit"
    screen.blit(font.render(status, True, BLACK), (12, 10))
    screen.blit(font.render(controls, True, (75, 82, 90)), (12, 34))


def main() -> None:
    parser = argparse.ArgumentParser(description="Interactive Langton's Ant simulation")
    parser.add_argument("--width", type=int, default=100, help="Grid width in cells")
    parser.add_argument("--height", type=int, default=75, help="Grid height in cells")
    parser.add_argument("--cell-size", type=int, default=8, help="Pixel size of each cell")
    parser.add_argument("--speed", type=int, default=500, help="Simulation steps per second")
    parser.add_argument("--no-grid", action="store_true", help="Hide grid lines")
    args = parser.parse_args()

    if min(args.width, args.height, args.cell_size, args.speed) <= 0:
        parser.error("width, height, cell-size, and speed must all be positive")

    pygame.init()
    pygame.display.set_caption("Langton's Ant — Cellular Automaton")
    panel_height = 62
    screen = pygame.display.set_mode(
        (args.width * args.cell_size, args.height * args.cell_size + panel_height)
    )
    clock = pygame.time.Clock()
    font = pygame.font.SysFont("consolas", 16)
    ant = LangtonsAnt(args.width, args.height)

    running = True
    paused = False
    speed = args.speed
    accumulator = 0.0
    step_interval = 1.0 / speed

    while running:
        dt = clock.tick(60) / 1000.0

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key in (pygame.K_ESCAPE, pygame.K_q):
                    running = False
                elif event.key == pygame.K_SPACE:
                    paused = not paused
                    accumulator = 0.0
                elif event.key == pygame.K_r:
                    ant.reset()
                    accumulator = 0.0
                elif event.key == pygame.K_RIGHT and paused:
                    ant.step()
                elif event.key == pygame.K_UP:
                    speed = min(speed * 2, 100_000)
                    step_interval = 1.0 / speed
                elif event.key == pygame.K_DOWN:
                    speed = max(speed // 2, 1)
                    step_interval = 1.0 / speed

        if not paused:
            accumulator += dt
            steps_this_frame = 0
            while accumulator >= step_interval and steps_this_frame < 5000:
                ant.step()
                accumulator -= step_interval
                steps_this_frame += 1

        draw_simulation(screen, ant, args.cell_size, panel_height, font,
                        show_grid=not args.no_grid)
        if paused:
            pause_label = font.render("PAUSED", True, ANT_COLOR)
            screen.blit(pause_label, (screen.get_width() - 90, 10))
        pygame.display.flip()

    pygame.quit()
    sys.exit(0)


if __name__ == "__main__":
    main()
